import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../features/navigation/app_section.dart';
import 'theme/app_colors.dart';
import 'widgets/app_logo.dart';

/// Общая верхняя строка: значок и название слева, вкладки по центру,
/// «Настройки» справа. Активная вкладка подчёркнута фиолетовой линией.
class TopBar extends ConsumerWidget {
  const TopBar({super.key});

  static const height = 64.0;
  static const _sideWidth = 210.0;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final current = ref.watch(currentSectionProvider);
    final navigation = ref.read(currentSectionProvider.notifier);

    return Container(
      height: height,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        children: [
          const SizedBox(
            width: _sideWidth,
            child: Row(
              children: [
                AppLogo(size: 36),
                SizedBox(width: 10),
                Flexible(
                  child: Text(
                    'Dirronlive',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                      color: AppColors.text,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (final tab in AppSection.tabs)
                    _TabButton(
                      section: tab,
                      selected: tab == current,
                      onTap: () => navigation.open(tab),
                    ),
                ],
              ),
            ),
          ),
          SizedBox(
            width: _sideWidth,
            child: Align(
              alignment: Alignment.centerRight,
              child: _SettingsButton(
                selected: current == AppSection.settings,
                onTap: () => navigation.openSettings(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TabButton extends StatelessWidget {
  const _TabButton({
    required this.section,
    required this.selected,
    required this.onTap,
  });

  final AppSection section;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      key: Key('nav-${section.name}'),
      onTap: onTap,
      child: SizedBox(
        height: TopBar.height - 1,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 3),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: Center(
                  child: Text(
                    section.label,
                    maxLines: 1,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                      color: selected ? AppColors.text : AppColors.textMuted,
                    ),
                  ),
                ),
              ),
            ),
            // Тонкая линия активной вкладки: переход от фиолетового к розовому.
            AnimatedContainer(
              key: selected ? Key('tab-line-${section.name}') : null,
              duration: const Duration(milliseconds: 160),
              height: 3,
              width: selected ? 44 : 0,
              decoration: BoxDecoration(
                gradient: AppColors.brandGradient,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SettingsButton extends StatelessWidget {
  const _SettingsButton({required this.selected, required this.onTap});

  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.accent : AppColors.text;
    return Material(
      color: selected ? AppColors.accent.withAlpha(38) : AppColors.surfaceHigh,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        key: const Key('nav-settings'),
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.settings_rounded, size: 20, color: color),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  'Настройки',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: color,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
