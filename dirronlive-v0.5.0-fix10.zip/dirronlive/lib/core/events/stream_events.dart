import 'app_event.dart';
import 'event_source.dart';
import 'gift_event.dart';

/// Лайки зрителя (TikTok присылает пачками: likeCount за пачку).
class LikeEvent extends AppEvent {
  LikeEvent({
    required this.viewerId,
    required this.viewerName,
    required this.likes,
    this.totalLikes,
    this.sourceKey,
    this.viewerAvatar,
    this.source = EventSource.tiktok,
  })  : id = generateEventId(),
        createdAt = DateTime.now();

  @override
  final String id;
  @override
  final DateTime createdAt;
  final String viewerId;
  final String viewerName;
  final int likes;

  /// Всего лайков эфира (если TikTok прислал).
  final int? totalLikes;
  /// Аватарка зрителя от TikTok, если пришла.
  final String? viewerAvatar;
  final String? sourceKey;
  final EventSource source;
}

/// Новая подписка на стримера.
class FollowEvent extends AppEvent {
  FollowEvent({
    required this.viewerId,
    required this.viewerName,
    this.sourceKey,
    this.viewerAvatar,
    this.source = EventSource.tiktok,
  })  : id = generateEventId(),
        createdAt = DateTime.now();

  @override
  final String id;
  @override
  final DateTime createdAt;
  final String viewerId;
  final String viewerName;
  /// Аватарка зрителя от TikTok, если пришла.
  final String? viewerAvatar;
  final String? sourceKey;
  final EventSource source;
}

/// Сообщение в чате эфира.
class ChatEvent extends AppEvent {
  ChatEvent({
    required this.viewerId,
    required this.viewerName,
    required this.text,
    this.sourceKey,
    this.viewerAvatar,
    this.source = EventSource.tiktok,
  })  : id = generateEventId(),
        createdAt = DateTime.now();

  @override
  final String id;
  @override
  final DateTime createdAt;
  final String viewerId;
  final String viewerName;
  final String text;
  /// Аватарка зрителя от TikTok, если пришла.
  final String? viewerAvatar;
  final String? sourceKey;
  final EventSource source;
}

/// Сведения об эфире после подключения.
class RoomInfoEvent extends AppEvent {
  RoomInfoEvent({
    required this.uniqueId,
    this.roomId,
    this.startedAt,
    this.followers,
  })  : id = generateEventId(),
        createdAt = DateTime.now();

  @override
  final String id;
  @override
  final DateTime createdAt;
  final String uniqueId;
  final String? roomId;

  /// Начало трансляции (если TikTok сообщил).
  final DateTime? startedAt;

  /// Подписчиков у стримера на момент подключения.
  final int? followers;
}
