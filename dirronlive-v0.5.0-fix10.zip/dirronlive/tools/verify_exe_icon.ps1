﻿# Проверяет, что в собранный dirronlive.exe попал значок Dirronlive
# (фиолетовая «D»), а не стандартный синий значок Flutter.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$exe = Join-Path $root 'build\windows\x64\runner\Release\dirronlive.exe'
Add-Type -AssemblyName System.Drawing
$icon = [System.Drawing.Icon]::ExtractAssociatedIcon($exe)
$bmp = $icon.ToBitmap()
[double]$r = 0; [double]$g = 0; [double]$b = 0; $n = 0
for ($x = 0; $x -lt $bmp.Width; $x++) {
    for ($y = 0; $y -lt $bmp.Height; $y++) {
        $p = $bmp.GetPixel($x, $y)
        if ($p.A -gt 128) { $r += $p.R; $g += $p.G; $b += $p.B; $n++ }
    }
}
if ($n -eq 0) { Write-Host "::error title=exe icon::значок exe пустой"; exit 1 }
$r = [math]::Round($r / $n); $g = [math]::Round($g / $n); $b = [math]::Round($b / $n)
Write-Host "::notice title=exe icon::$($bmp.Width)x$($bmp.Height), средний цвет R=$r G=$g B=$b"
if (-not ($r -gt $g + 15 -and $b -gt $g + 15)) {
    Write-Host "::error title=exe icon::в dirronlive.exe не значок Dirronlive (похоже на значок Flutter)"
    exit 1
}
