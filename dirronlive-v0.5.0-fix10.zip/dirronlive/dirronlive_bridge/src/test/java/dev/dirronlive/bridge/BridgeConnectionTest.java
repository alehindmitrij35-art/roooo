package dev.dirronlive.bridge;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.net.URI;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.junit.jupiter.api.Test;

/** Мод против настоящего WebSocket-сервера: без Minecraft, с поддельной «игрой». */
class BridgeConnectionTest {

    /** «Игра»: один игровой поток, как у Minecraft, и список показанных подарков. */
    static final class FakeGame implements BridgeConnection.Game {
        final ExecutorService gameThread = Executors.newSingleThreadExecutor();
        final List<BridgeProtocol.Gift> shown = new CopyOnWriteArrayList<>();
        final List<String> threads = new CopyOnWriteArrayList<>();
        volatile boolean worldReady;
        volatile String gameThreadName;

        FakeGame() throws Exception {
            gameThreadName = gameThread.submit(() -> Thread.currentThread().getName()).get();
        }

        @Override
        public boolean isWorldReady() {
            return worldReady;
        }

        @Override
        public void runOnGameThread(Runnable task) {
            gameThread.execute(task);
        }

        @Override
        public boolean showGift(BridgeProtocol.Gift gift) {
            threads.add(Thread.currentThread().getName());
            if (!worldReady) return false;
            shown.add(gift);
            return true;
        }

        final List<BridgeProtocol.Action> actions = new CopyOnWriteArrayList<>();
        volatile int room = 12;

        @Override
        public void runAction(BridgeProtocol.Action action, java.util.function.Consumer<BridgeProtocol.ActionResult> done) {
            threads.add(Thread.currentThread().getName());
            int accepted = acceptedById.getOrDefault(action.id(), 0);
            int from = firstRoom.computeIfAbsent(action.id(), k -> room);
            // Как очередь мода: выполняется только прирост total.
            for (int i = accepted; i < action.total(); i++) {
                actions.add(action);
                room = Math.max(1, room - 1);
            }
            acceptedById.put(action.id(), Math.max(accepted, action.total()));
            int total = acceptedById.get(action.id());
            done.accept(new BridgeProtocol.ActionResult(true, "Комната " + from + " → " + room, room,
                    total, total, 0, true));
        }

        final java.util.Map<String, Integer> acceptedById = new java.util.concurrent.ConcurrentHashMap<>();
        final java.util.Map<String, Integer> firstRoom = new java.util.concurrent.ConcurrentHashMap<>();

        @Override
        public BridgeProtocol.ParkourStatus parkourStatus() {
            return new BridgeProtocol.ParkourStatus(worldReady, room, false, 0, 0);
        }
    }

    static String action(String id) {
        return action(id, 1);
    }

    static String action(String id, int total) {
        return "{\"type\":\"action\",\"id\":\"" + id + "\",\"action\":\"room_back\","
                + "\"params\":{\"rooms\":1},\"label\":\"Роза\",\"viewerName\":\"Тест\",\"test\":true,"
                + "\"total\":" + total + "}";
    }

    static BridgeConnection connect(TestWebSocketServer server, FakeGame game) {
        BridgeConnection connection = new BridgeConnection(
                URI.create("ws://127.0.0.1:" + server.port() + "/dirronlive"),
                game, "1.0.0", "1.21.1", Duration.ofMillis(200), message -> {});
        connection.start();
        return connection;
    }

    static String gift(String id) {
        return MiniJson.object("type", "gift", "id", id,
                "viewerName", "Тестовый зритель", "giftName", "Роза", "count", 1);
    }

    @Test
    void helloWithVersionsAndWorldState() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = false;
            BridgeConnection connection = connect(server, game);

            String hello = server.nextOfType("hello", 5000);
            assertNotNull(hello, "мод должен представиться");
            Map<String, Object> m = MiniJson.parseObject(hello);
            assertEquals("1.0.0", m.get("modVersion"));
            assertEquals("1.21.1", m.get("minecraftVersion"));
            assertEquals(Boolean.FALSE, m.get("worldReady"));
            assertEquals(2L, m.get("protocol"));

            connection.onWorldState(true); // вошёл в мир
            assertEquals(Boolean.TRUE,
                    MiniJson.parseObject(server.nextOfType("world", 3000)).get("worldReady"));
            connection.onWorldState(true); // тот же статус — не дублируется
            connection.onWorldState(false); // вышел в меню
            assertEquals(Boolean.FALSE,
                    MiniJson.parseObject(server.nextOfType("world", 3000)).get("worldReady"));
            connection.stop();
        }
    }

    @Test
    void giftIsShownOnGameThreadThenAcknowledged() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = true;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));

            server.send(gift("id-1"));
            String ack = server.nextOfType("ack", 3000);
            assertNotNull(ack, "подтверждение после показа");
            assertEquals("id-1", MiniJson.parseObject(ack).get("id"));
            assertEquals(1, game.shown.size());
            assertEquals("Dirronlive • Тестовый зритель отправил «Роза» ×1", game.shown.get(0).overlayText());
            assertEquals(List.of(game.gameThreadName), game.threads, "показ — только в игровом потоке");
            connection.stop();
        }
    }

    @Test
    void duplicateIdIsAcknowledgedAgainButShownOnce() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = true;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));

            server.send(gift("same"));
            server.send(gift("same"));
            assertEquals("same", MiniJson.parseObject(server.nextOfType("ack", 3000)).get("id"));
            assertEquals("same", MiniJson.parseObject(server.nextOfType("ack", 3000)).get("id"));
            assertEquals(1, game.shown.size());
            connection.stop();
        }
    }

    @Test
    void threeQuickGiftsGetThreeAcks() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = true;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));

            server.send(gift("a"));
            server.send(gift("b"));
            server.send(gift("c"));
            List<Object> acks = new CopyOnWriteArrayList<>();
            for (int i = 0; i < 3; i++) {
                acks.add(MiniJson.parseObject(server.nextOfType("ack", 3000)).get("id"));
            }
            assertEquals(List.of("a", "b", "c"), acks);
            assertEquals(3, game.shown.size());
            connection.stop();
        }
    }

    @Test
    void comboStepsAreShownImmediatelyEachWithOwnAck() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = true;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));

            for (int total = 1; total <= 5; total++) {
                server.send(MiniJson.object("type", "gift", "id", "combo:" + total,
                        "viewerName", "Тестовый зритель", "giftName", "Роза",
                        "count", 1, "combo", true, "comboTotal", total));
                assertEquals("combo:" + total,
                        MiniJson.parseObject(server.nextOfType("ack", 3000)).get("id"));
            }
            assertEquals(5, game.shown.size());
            assertEquals("Dirronlive • Тестовый зритель отправил «Роза» ×5", game.shown.get(4).overlayText());
            connection.stop();
        }
    }

    @Test
    void noAckWhenWorldIsNotReady() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = false;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));

            server.send(gift("menu"));
            assertNull(server.nextOfType("ack", 700), "в меню подарок не подтверждается");
            assertTrue(game.shown.isEmpty());
            connection.stop();
        }
    }

    @Test
    void reconnectsAfterDropAndWhenServerStartsLater() throws Exception {
        int port;
        try (TestWebSocketServer probe = new TestWebSocketServer()) {
            port = probe.port();
        }
        FakeGame game = new FakeGame();
        game.worldReady = true;
        // Игра запущена раньше программы: сервера пока нет.
        BridgeConnection connection = new BridgeConnection(
                URI.create("ws://127.0.0.1:" + port + "/dirronlive"),
                game, "1.0.0", "1.21.1", Duration.ofMillis(200), message -> {});
        connection.start();
        Thread.sleep(600);
        assertFalse(connection.isConnected());

        try (TestWebSocketServer server = new TestWebSocketServer(port)) {
            assertNotNull(server.nextOfType("hello", 5000), "подключился, когда программа появилась");
            assertEquals(1, server.connections());

            server.dropClient(); // программу закрыли / связь оборвалась
            assertTrue(server.awaitClient(5000)); // первое подключение
            assertTrue(server.awaitClient(5000), "переподключился после разрыва");
            assertNotNull(server.nextOfType("hello", 5000));
            assertEquals(2, server.connections());

            server.send(gift("after-reconnect"));
            assertNotNull(server.nextOfType("ack", 3000));
        } finally {
            connection.stop();
        }
    }

    @Test
    void actionRunsOnceOnGameThreadAndRepeatsResultForSameId() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            game.worldReady = true;
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));
            Map<String, Object> status = MiniJson.parseObject(server.nextOfType("parkour", 3000));
            assertEquals(12L, status.get("room"));

            server.send(action("t1"));
            Map<String, Object> r = MiniJson.parseObject(server.nextOfType("actionResult", 3000));
            assertEquals("t1", r.get("id"));
            assertEquals(Boolean.TRUE, r.get("ok"));
            assertEquals("Комната 12 → 11", r.get("result"));

            server.send(action("t1"));
            Map<String, Object> again = MiniJson.parseObject(server.nextOfType("actionResult", 3000));
            assertEquals("Комната 12 → 11", again.get("result"), "повтор ID возвращает прежний результат");
            assertEquals(1, game.actions.size(), "повтор ID не выполняется второй раз");
            assertEquals(game.gameThreadName, game.threads.get(0));

            connection.onParkourStatus(game.parkourStatus());
            assertEquals(11L, MiniJson.parseObject(server.nextOfType("parkour", 3000)).get("room"));

            // Серия растёт: ×3 добавляет только две штуки, повтор ×3 — ничего.
            server.send(action("t1", 3));
            Map<String, Object> grown = MiniJson.parseObject(server.nextOfType("actionResult", 3000));
            assertEquals(3L, grown.get("accepted"));
            assertEquals("Комната 12 → 9", grown.get("result"));
            server.send(action("t1", 3));
            server.nextOfType("actionResult", 3000);
            assertEquals(3, game.actions.size(), "повтор total не добавляет срабатываний");
            connection.stop();
        }
    }

    @Test
    void actionWithClosedWorldIsRefusedAndNotRemembered() throws Exception {
        try (TestWebSocketServer server = new TestWebSocketServer()) {
            FakeGame game = new FakeGame();
            BridgeConnection connection = connect(server, game);
            assertNotNull(server.nextOfType("hello", 5000));
            server.send(action("t2"));
            Map<String, Object> r = MiniJson.parseObject(server.nextOfType("actionResult", 3000));
            assertEquals(Boolean.FALSE, r.get("ok"));
            assertEquals(0, game.actions.size());
            game.worldReady = true;
            server.send(action("t2"));
            Map<String, Object> ok = MiniJson.parseObject(server.nextOfType("actionResult", 3000));
            assertEquals(Boolean.TRUE, ok.get("ok"));
            assertEquals(1, game.actions.size());
            connection.stop();
        }
    }
}
