// Чистые функции коннектора (без зависимостей) — их проверяют тесты.

/** BigInt/Long/число/строка → строка; пустое → null. */
export function idString(value) {
  if (value === undefined || value === null) return null;
  const text = typeof value === 'object' && typeof value.toString === 'function'
    ? value.toString()
    : String(value);
  return text === '' || text === '0' ? null : text;
}

function toInt(value, fallback) {
  const n = Number(typeof value === 'bigint' ? value : value ?? NaN);
  return Number.isFinite(n) ? Math.trunc(n) : fallback;
}

/**
 * Подарок из tiktok-live-connector → плоский JSON для Dirronlive.
 * Поля читаются с запасными вариантами: в разных версиях библиотеки и
 * протокола TikTok они лежат в разных местах.
 */
export function normalizeGift(data) {
  const d = data ?? {};
  const details = d.giftDetails ?? d.gift ?? {};
  const user = d.user ?? {};
  const common = d.common ?? {};
  const giftType = toInt(details.giftType ?? d.giftType, 0);
  const repeatEndRaw = d.repeatEnd;
  return {
    type: 'gift',
    msgId: idString(common.msgId ?? d.msgId ?? d.logId),
    groupId: idString(d.groupId ?? details.groupId),
    giftId: idString(d.giftId ?? details.id) ?? 'unknown',
    giftName: String(
      details.giftName ?? d.extendedGiftInfo?.name ?? d.giftName ?? `Подарок ${d.giftId ?? ''}`,
    ).trim(),
    giftType,
    streakable: giftType === 1,
    repeatCount: Math.max(1, toInt(d.repeatCount, 1)),
    repeatEnd: repeatEndRaw === true || repeatEndRaw === 1 || repeatEndRaw === '1',
    userId: idString(user.userId ?? user.id ?? d.userId),
    uniqueId: user.uniqueId ? String(user.uniqueId) : null,
    nickname: user.nickname ? String(user.nickname) : null,
    avatar: avatarUrl(user),
    createTime: idString(common.createTime ?? d.createTime),
    diamondCount: Math.max(0, toInt(details.diamondCount ?? details.diamond_count ?? d.diamondCount
      ?? d.extendedGiftInfo?.diamond_count, 0)),
    giftImage: imageUrl({ image: details.giftImage?.giftPictureUrl ?? details.image ?? details.icon
      ?? d.extendedGiftInfo?.image ?? d.giftPictureUrl }),
  };
}

/**
 * Аватарка зрителя: в разных версиях протокола лежит в profilePicture.url[],
 * profilePicture.urlList[], avatarThumb.urlList[] или profilePictureUrl.
 * Берём https-ссылку (их отдают CDN TikTok), иначе первую подходящую.
 */
export function avatarUrl(user) {
  const u = user ?? {};
  const lists = [u.profilePicture, u.avatarThumb, u.avatarMedium, u.avatarLarger, u.avatar_thumb, u.avatar]
    .map((p) => (typeof p === 'string' ? [p] : (p?.url ?? p?.urlList ?? p?.url_list ?? [])))
    .concat([[u.profilePictureUrl], [u.avatarUrl]]);
  const urls = lists.flat().filter((x) => typeof x === 'string' && /^https?:\/\//.test(x));
  return urls.find((x) => x.startsWith('https://')) ?? urls[0] ?? null;
}

function userFields(d) {
  const user = d?.user ?? {};
  return {
    userId: idString(user.userId ?? user.id ?? d?.userId),
    uniqueId: user.uniqueId ? String(user.uniqueId) : null,
    nickname: user.nickname ? String(user.nickname) : null,
    avatar: avatarUrl(user),
    msgId: idString(d?.common?.msgId ?? d?.msgId),
  };
}

/** Лайки: likeCount — сколько в этой пачке, totalLikeCount — всего у эфира. */
export function normalizeLike(data) {
  const d = data ?? {};
  return { type: 'like', ...userFields(d), likeCount: Math.max(1, toInt(d.likeCount ?? d.count, 1)),
    totalLikeCount: d.totalLikeCount == null ? null : toInt(d.totalLikeCount, 0) };
}

/** Подписка на стримера (social-событие с displayType follow). */
export function normalizeFollow(data) {
  return { type: 'follow', ...userFields(data ?? {}) };
}

/** Сообщение чата. */
export function normalizeChat(data) {
  const d = data ?? {};
  return { type: 'chat', ...userFields(d), comment: String(d.comment ?? d.content ?? '').slice(0, 300) };
}

/** Сведения об эфире: начало трансляции (секунды) и число подписчиков. */
export function normalizeRoom(roomInfo, roomId) {
  const r = roomInfo ?? {};
  const owner = r.owner ?? r.data?.owner ?? {};
  const start = toInt(r.create_time ?? r.createTime ?? r.data?.create_time ?? r.start_time, 0);
  const followers = owner.follow_info?.follower_count ?? owner.followInfo?.followerCount ?? r.stats?.follower_count;
  return { type: 'room', roomId: roomId ? String(roomId) : null, startTime: start > 0 ? start : null,
    followers: followers == null ? null : toInt(followers, 0) };
}

const NETWORK_CODES = [
  'ENOTFOUND', 'ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'EAI_AGAIN',
  'ENETUNREACH', 'EHOSTUNREACH', 'ECONNABORTED', 'EPIPE', 'UND_ERR_CONNECT_TIMEOUT',
];

/**
 * Ошибка подключения → статус для Dirronlive:
 *   offline  — эфир не идёт (UserOfflineError);
 *   network  — нет сети / не отвечает сервер;
 *   service  — TikTok или сервер подписи Euler Stream отказали (лимиты и т. п.).
 */
export function classifyError(error) {
  const name = String(error?.name ?? error?.constructor?.name ?? 'Error');
  const message = String(error?.message ?? error ?? '');
  const code = String(error?.code ?? error?.cause?.code ?? '');
  const text = `${name} ${code} ${message}`;

  if (/UserOffline/i.test(text) || /isn't online|is not online|not live|offline/i.test(message)) {
    return { status: 'offline', kind: 'offline', message: 'Эфир не найден: аккаунт сейчас не в эфире.' };
  }
  if (/InvalidUniqueId/i.test(text) || /user.*not.*found|unique.?id/i.test(message)) {
    return { status: 'error', kind: 'service', message: 'TikTok не нашёл такой аккаунт. Проверьте ник.' };
  }
  if (/RateLimit/i.test(text) || /\b429\b/.test(text)) {
    return {
      status: 'error', kind: 'service',
      message: 'Сервер подписи Euler Stream ограничил частоту подключений. Подождите минуту или укажите свой бесплатный ключ Euler Stream.',
    };
  }
  if (NETWORK_CODES.some((c) => text.includes(c)) || /ConnectTimeout|network|fetch failed|socket hang up|timed? ?out/i.test(text)) {
    return { status: 'error', kind: 'network', message: `Ошибка сети: ${message || code}`.trim() };
  }
  return { status: 'error', kind: 'service', message: `Ошибка сервиса TikTok LIVE: ${message || name}` };
}

/** Разбор аргументов: --user ник [--key ключ] [--self-check] [--fetch-gifts]. */
export function parseArgs(argv) {
  const args = { user: null, key: null, selfCheck: false, fetchGifts: false, lang: 'ru-RU' };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--self-check') args.selfCheck = true;
    else if (a === '--fetch-gifts') args.fetchGifts = true;
    else if (a === '--user') args.user = argv[++i] ?? null;
    else if (a === '--key') args.key = argv[++i] ?? null;
    else if (a === '--lang') args.lang = argv[++i] ?? 'ru-RU';
  }
  if (args.user) args.user = args.user.trim().replace(/^@/, '');
  if (args.key) args.key = args.key.trim() || null;
  return args;
}

/**
 * Общий список подарков TikTok LIVE (тот же, что видит сайт tiktok.com):
 * без входа, без эфира и без cookies. Регион определяет TikTok по IP,
 * язык названий — параметр lang.
 */
export function publicGiftListUrl(lang = 'ru-RU') {
  const l = /^[a-z]{2}(-[A-Z]{2})?$/.test(lang) ? lang : 'ru-RU';
  const q = new URLSearchParams({
    aid: '1988', app_name: 'tiktok_web', device_platform: 'web_pc',
    app_language: l, webcast_language: l, browser_language: l,
  });
  return `https://webcast.tiktok.com/webcast/gift/list/?${q}`;
}

/** Ответ webcast/gift/list → [{id, name, diamonds, image}] или ошибка с понятным текстом. */
export function parsePublicGiftList(json) {
  if (!json || typeof json !== 'object') throw new Error('TikTok вернул не JSON');
  if (json.status_code && json.status_code !== 0) {
    throw new Error(`TikTok ответил кодом ${json.status_code}${json.data?.message ? `: ${json.data.message}` : ''}`);
  }
  const gifts = normalizeCatalog(json.data?.gifts ?? []);
  if (!gifts.length) throw new Error('TikTok прислал пустой список подарков');
  return gifts;
}

/** JSON.stringify, который не падает на BigInt. */
export function toJsonLine(object) {
  return JSON.stringify(object, (_k, v) => (typeof v === 'bigint' ? v.toString() : v));
}

/** Первая ссылка на картинку из разных форм ответа TikTok. */
function imageUrl(gift) {
  const candidates = [gift?.image, gift?.icon, gift?.giftImage, gift?.image_url];
  for (const c of candidates) {
    if (typeof c === 'string' && c.startsWith('http')) return c;
    const list = c?.url_list ?? c?.urlList ?? c?.url;
    if (Array.isArray(list) && typeof list[0] === 'string') return list[0];
    if (typeof list === 'string' && list.startsWith('http')) return list;
  }
  return null;
}

/**
 * Каталог подарков эфира (fetchAvailableGifts) → [{id, name, diamonds, image}].
 * Подарки без ID или названия отбрасываются, повторы ID — тоже.
 */
export function normalizeCatalog(list) {
  const items = Array.isArray(list) ? list : (list?.gifts ?? list?.giftList ?? []);
  const seen = new Set();
  const out = [];
  for (const g of Array.isArray(items) ? items : []) {
    const id = idString(g?.id ?? g?.giftId);
    const name = String(g?.name ?? g?.giftName ?? '').trim();
    if (!id || !name || seen.has(id)) continue;
    seen.add(id);
    out.push({ id, name, diamonds: Math.max(0, toInt(g?.diamond_count ?? g?.diamondCount, 0)), image: imageUrl(g) });
  }
  return out;
}
